import React, { useEffect, useState } from 'react';
import {
  Route,
  BrowserRouter as Router,
  Switch
} from "react-router-dom";
import './App.css';
import About from './T-parts/About';
import Alert from './T-parts/Alert';
import Navbar from './T-parts/Navbar';
import TextForm from './T-parts/TextForm';
 
function App() {
  const [mode, setMode] = useState('light'); // Whether dark mode is enabled or not
  const [alert, setAlert] = useState(null);

  const showAlert = (message, type)=>{
      setAlert({
        msg: message,
        type: type
      })
      setTimeout(() => {
          setAlert(null);
      }, 1500);
  }

  const toggleMode = ()=>{
    if(mode === 'light'){
      setMode('dark');
      document.body.style.backgroundColor = 'rgb(8, 38, 19)';
      showAlert("Dark mode has been enabled", "success");
      
    }
    else{
      setMode('light');
      document.body.style.backgroundColor = 'rgb(179, 201, 172)';
      showAlert("Light mode has been enabled", "success");
    }
  }

  useEffect(() => {
    document.body.style.zoom = "80%";
  }, []);

    // const apna = {
    //     backgroundImage: "url('bgbg.jpg')",
    //     // height: "100vh",
    //     // marginTop: "-70px",
    //     // fontSize: "50px",
    //     // backgroundSize: "cover",
    //     // backgroundRepeat: "no-repeat",
    //     }

  return (
    <>
    {/* <div className="container" style={apna}> */}
    <Router>
    <Navbar title="Texty" mode={mode} toggleMode={toggleMode} key={new Date()} />
    <Alert alert={alert}/>
    <div className="container ">
    <Switch>
    {/* /users --> Component 1
        /users/home --> Component 2 */} 
          <Route exact path="/about"> 
            <About mode={mode}/>
          </Route>
          <Route >
            <TextForm showAlert={showAlert} heading="Enter your text below and manipulate it the way you want..." mode={mode} />
          </Route>
    </Switch>
     {/* {<About mode={mode}/>}  */}
    </div>
    {/* <Footer/> */}
    </Router>
    {/* </div> */}
    </> 
  );
}


export default App;